# WARNING: This file will be overwritten by the Ansible install script.
KEYSPACE = 'indigo'
LOG_LEVEL = 'INFO'
CASSANDRA_HOSTS = ('127.0.0.1', )
