"""
Tests Alloy against the `CDMI version 1.1.1 spec <http://cdmi.sniacloud.com/>`_
"""

import nose


if __name__ == '__main__':
    nose.main()